-- Insert data into EMPLOYEE Table
--INSERT INTO employees VALUES ('1','Raman','Verma','raman@gl.com');
--INSERT INTO employees VALUES ('2','Sahil','Shah','sahil@gl.com');
--INSERT INTO employees VALUES ('3','Akshay','Shaligram','akshay@gl.com');
--INSERT INTO employees VALUES ('4','Akshata','Joshi','akshata@gl.com');
--INSERT INTO employees VALUES ('5','Suchita','Roy','suchita@gl.com');


INSERT INTO employees VALUES ('1','raman@gl.com','Raman','Verma');
INSERT INTO employees VALUES ('2','sahil@gl.com','Sahil','Shah');
INSERT INTO employees VALUES ('3','akshay@gl.com','Akshay','Shaligram');
INSERT INTO employees VALUES ('4','akshata@gl.com','Akshata','Joshi');
INSERT INTO employees VALUES ('5','suchita@gl.com','Suchita','Roy');
INSERT INTO employees VALUES ('6','akshay@gl.com','Akshay','ROY');
INSERT INTO employees VALUES ('7','sahil@gl.com','Sahil','VERMA');

